// Simple K-Means color quantization that runs in the browser.
// Returns a data URL of the quantized image.

export async function quantizeImage(
  source: HTMLImageElement | string,
  k: number,
  maxDim = 800,
): Promise<string> {
  const img =
    typeof source === "string"
      ? await loadImage(source)
      : await ensureLoaded(source);

  // Downscale large images for snappy processing while keeping output size
  const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
  const w = Math.max(1, Math.round(img.naturalWidth * scale));
  const h = Math.max(1, Math.round(img.naturalHeight * scale));

  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, w, h);
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Sample pixels for clustering speed
  const sampleCount = Math.min(15000, (w * h));
  const stride = Math.max(1, Math.floor((w * h) / sampleCount));
  const samples: number[][] = [];
  for (let i = 0; i < w * h; i += stride) {
    const p = i * 4;
    samples.push([data[p], data[p + 1], data[p + 2]]);
  }

  const centroids = kmeans(samples, k, 12);

  // Map every pixel to nearest centroid
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i],
      g = data[i + 1],
      b = data[i + 2];
    let best = 0;
    let bestDist = Infinity;
    for (let c = 0; c < centroids.length; c++) {
      const cc = centroids[c];
      const dr = r - cc[0],
        dg = g - cc[1],
        db = b - cc[2];
      const d = dr * dr + dg * dg + db * db;
      if (d < bestDist) {
        bestDist = d;
        best = c;
      }
    }
    const cc = centroids[best];
    data[i] = cc[0];
    data[i + 1] = cc[1];
    data[i + 2] = cc[2];
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL("image/png");
}

function kmeans(points: number[][], k: number, iterations: number): number[][] {
  if (points.length === 0) return [];
  k = Math.max(1, Math.min(k, points.length));

  // k-means++ init
  const centroids: number[][] = [];
  centroids.push(points[Math.floor(Math.random() * points.length)].slice());
  while (centroids.length < k) {
    const dists = points.map((p) => {
      let min = Infinity;
      for (const c of centroids) {
        const d =
          (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2;
        if (d < min) min = d;
      }
      return min;
    });
    const sum = dists.reduce((a, b) => a + b, 0);
    let r = Math.random() * sum;
    let idx = 0;
    for (let i = 0; i < dists.length; i++) {
      r -= dists[i];
      if (r <= 0) {
        idx = i;
        break;
      }
    }
    centroids.push(points[idx].slice());
  }

  const assignments = new Array(points.length).fill(0);

  for (let iter = 0; iter < iterations; iter++) {
    let changed = false;
    for (let i = 0; i < points.length; i++) {
      const p = points[i];
      let best = 0;
      let bestD = Infinity;
      for (let c = 0; c < centroids.length; c++) {
        const cc = centroids[c];
        const d =
          (p[0] - cc[0]) ** 2 + (p[1] - cc[1]) ** 2 + (p[2] - cc[2]) ** 2;
        if (d < bestD) {
          bestD = d;
          best = c;
        }
      }
      if (assignments[i] !== best) {
        assignments[i] = best;
        changed = true;
      }
    }

    const sums = Array.from({ length: k }, () => [0, 0, 0, 0]);
    for (let i = 0; i < points.length; i++) {
      const a = assignments[i];
      const p = points[i];
      sums[a][0] += p[0];
      sums[a][1] += p[1];
      sums[a][2] += p[2];
      sums[a][3] += 1;
    }
    for (let c = 0; c < k; c++) {
      if (sums[c][3] > 0) {
        centroids[c] = [
          Math.round(sums[c][0] / sums[c][3]),
          Math.round(sums[c][1] / sums[c][3]),
          Math.round(sums[c][2] / sums[c][3]),
        ];
      }
    }
    if (!changed) break;
  }

  return centroids;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function ensureLoaded(img: HTMLImageElement): Promise<HTMLImageElement> {
  if (img.complete && img.naturalWidth > 0) return Promise.resolve(img);
  return new Promise((resolve, reject) => {
    img.onload = () => resolve(img);
    img.onerror = reject;
  });
}
